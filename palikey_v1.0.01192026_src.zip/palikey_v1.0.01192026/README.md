# Palikey

Palikey is a cross-platform virtual keyboard targeting:
- Android (IME)
- iOS (Keyboard Extension)
- PalisadeOS (Native App)

The project uses a shared C++ core for layout, spacing,
and theme logic, while each platform provides native
input and rendering.

All builds are designed to be signed and deployable
to real hardware.